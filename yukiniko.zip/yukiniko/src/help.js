const help = (prefix) => { 
	return `                 
┏━━°❀ ❬ *TENTANG BOT* ❭ ❀°━━┓
┃
┣➥ *${prefix}info*
┣➥ *${prefix}donasi*
┣➥ *${prefix}owner*
┣➥ *${prefix}speed*
┣➥ *${prefix}report [lapor bug]*
┃
┣━━━━°❀ ❬ *MEDIA* ❭ ❀°━━━━━⊱
┃
┣➥ *${prefix}stiker*
┣➥ *${prefix}tsticker*
┣➥ *${prefix}toimg*
┣➥ *${prefix}nulis*
┣➥ *${prefix}ocr*
┣➥ *${prefix}ytsearch*
┣➥ *${prefix}ytmp3*
┣➥ *${prefix}ytmp4*
┣➥ *${prefix}tiktok*
┣➥ *${prefix}tiktokstalk*
┣➥ *${prefix}fototiktok*
┣➥ *${prefix}igstalk*
┣➥ *${prefix}image*
┣➥ *${prefix}pinterest*
┣➥ *${prefix}tts*
┣➥ *${prefix}tes*
┣➥ *${prefix}tep*
┣➥ *${prefix}ttp*
┣➥ *${prefix}meme*
┣➥ *${prefix}memeindo*
┣➥ *${prefix}ssweb*
┣➥ *${prefix}walpaperhd*
┣➥ *${prefix}randomcat*
┣➥ *${prefix}joox*
┣➥ *${prefix}inu*
┣➥ *${prefix}elang*
┣➥ *${prefix}unta*
┣➥ *${prefix}anjing*
┣➥ *${prefix}babi*
┣➥ *${prefix}playstore*
┣➥ *${prefix}url2image*
┣➥ *${prefix}kbbi*
┣➥ *${prefix}imoji*
┣➥ *${prefix}wait*
┃
┣━━━━°❀ ❬ *CREATOR* ❭ ❀°━━━━⊱
┃
┣➥ *${prefix}thunder*
┣➥ *${prefix}tahta*
┣➥ *${prefix}glitch <teks|teks>*
┣➥ *${prefix}phlogo <teks|teks>*
┣➥ *${prefix}wolflogo <teks|teks>*
┣➥ *${prefix}wolflogo2 <teks|teks>*
┣➥ *${prefix}quotemaker <tx|wtrmk|tema>*
┣➥ *${prefix}galaxtext*
┣➥ *${prefix}textdark*
┣➥ *${prefix}textblue*
┣➥ *${prefix}lovemake*
┣➥ *${prefix}stiltext*
┣➥ *${prefix}ninjalogo*
┣➥ *${prefix}party*
┣➥ *${prefix}rtext*
┣➥ *${prefix}water*
┣➥ *${prefix}lionlogo <teks|teks>*
┣➥ *${prefix}textscreen*
┣➥ *${prefix}text3d*
┣➥ *${prefix}epep*
┣➥ *${prefix}marvelogo <teks|teks>*
┣➥ *${prefix}snow <teks|teks>*
┣➥ *${prefix}firetext*
┃
┣━━━°❀ ❬ *FUN&GAMES* ❭ ❀°━━━⊱
┃
┣➥ *${prefix}truth*
┣➥ *${prefix}dare*
┣➥ *${prefix}tebakgambar*
┣➥ *${prefix}family100*
┣➥ *${prefix}caklontong*
┣➥ *${prefix}game*
┣➥ *${prefix}primbonjodoh*
┣➥ *${prefix}ramaljadian*
┣➥ *${prefix}mlherolist*
┣➥ *${prefix}bucin*
┣➥ *${prefix}persengay*
┣➥ *${prefix}ramalhp <nomor>*
┣➥ *${prefix}ceckjodoh*
┃
┣━━━━━°❀ ❬ *ANIME* ❭ ❀°━━━━━⊱
┃
┣➥ *${prefix}openanime*
┣➥ *${prefix}Naruto*
┣➥ *${prefix}Minato*
┣➥ *${prefix}Boruto*
┣➥ *${prefix}Hinata*
┣➥ *${prefix}Sakura*
┣➥ *${prefix}Sasuke*
┣➥ *${prefix}kaneki*
┣➥ *${prefix}toukacan*
┣➥ *${prefix}rize*
┣➥ *${prefix}akira*
┣➥ *${prefix}itori*
┣➥ *${prefix}kurumi*
┣➥ *${prefix}miku*
┣➥ *${prefix}anime*
┣➥ *${prefix}nekonime*
┣➥ *${prefix}loli*
┣➥ *${prefix}loli2*
┣➥ *${prefix}waifu*
┣➥ *${prefix}waifu2*
┣➥ *${prefix}wibu*
┣➥ *${prefix}randomanime*
┣➥ *${prefix}pokemon*
┣➥ *${prefix}artinama*
┃
┣━━°❀ ❬ *INFO&EDUKASI* ❭ ❀°━━⊱
┃
┣➥ *${prefix}infogc*
┣➥ *${prefix}infogempa*
┣➥ *${prefix}infogithub*
┣➥ *${prefix}infocuaca*
┣➥ *${prefix}infonomor*
┣➥ *${prefix}infomobil*
┣➥ *${prefix}infomotor*
┣➥ *${prefix}grupinfo*
┣➥ *${prefix}lirik*
┣➥ *${prefix}quotes*
┣➥ *${prefix}cerpen*
┣➥ *${prefix}chord*
┣➥ *${prefix}wiki*
┣➥ *${prefix}brainly*
┣➥ *${prefix}resepmasakan*
┣➥ *${prefix}map*
┃
┣━━━━━°❀ ❬ *GRUP* ❭ ❀°━━━━━⊱
┃
┣➥ *${prefix}add*
┣➥ *${prefix}kick*
┣➥ *${prefix}promote*
┣➥ *${prefix}demote*
┣➥ *${prefix}setname*
┣➥ *${prefix}setdesc*
┣➥ *${prefix}welcome*
┣➥ *${prefix}nsfw*
┣➥ *${prefix}simih*
┣➥ *${prefix}grup [buka/tutup]*
┣➥ *${prefix}tagme*
┣➥ *${prefix}hidetag*
┣➥ *${prefix}tagall*
┣➥ *${prefix}otagall*
┣➥ *${prefix}fitnah*
┣➥ *${prefix}infogc*
┣➥ *${prefix}grupinfo*
┣➥ *${prefix}linkgrup*
┣➥ *${prefix}listadmins*
┣➥ *${prefix}openanime*
┣➥ *${prefix}edotense*
┣➥ *${prefix}kudeta*
┃
┣━━━━━°❀ ❬ *NSFW* ❭ ❀°━━━━━⊱
┃
┣➥ *${prefix}nsfwloli*
┣➥ *${prefix}nsfwblowjob*
┣➥ *${prefix}nsfwneko*
┣➥ *${prefix}nsfwtrap*
┣➥ *${prefix}randomhentai*
┣➥ *${prefix}hentai*
┣➥ *${prefix}indohot*
┃
┣━━━━°❀ ❬ *KERANG* ❭ ❀°━━━━━⊱
┃
┣➥ *${prefix}apakah*
┣➥ *${prefix}kapankah*
┣➥ *${prefix}bisakah*
┣➥ *${prefix}rate*
┣➥ *${prefix}watak*
┣➥ *${prefix}hobby*
┃
┣━━━━━°❀ ❬ *OTHER* ❭ ❀°━━━━━⊱
┃
┣➥ *${prefix}blocklist*
┣➥ *${prefix}testime*
┣➥ *${prefix}hilih*
┣➥ *${prefix}say*
┣➥ *${prefix}delete*
┣➥ *${prefix}shorturl*
┃
┣━━━━°❀ ❬ *OWNER* ❭ ❀°━━━━━⊱
┃
┣➥ *${prefix}bc*
┣➥ *${prefix}ban*
┣➥ *${prefix}block*
┣➥ *${prefix}unblock*
┣➥ *${prefix}clearall*
┣➥ *${prefix}clone*
┣➥ *${prefix}getses*
┣➥ *${prefix}setpp*
┣➥ *${prefix}setpp*
┣➥ *${prefix}leave*
┃
┣━━━━━°❀ ❬ *TQTO* ❭ ❀°━━━━━⊱
┃
┣➥ *${prefix}P042*
┣➥ *${prefix}ALFA*
┣➥ *${prefix}ARUGAZ*
┣➥ *${prefix}DUINGZ*
┣➥ *${prefix}YUKINIKO*
┣➥ *${prefix}MHANKBARBAR*
┣➥ *${prefix}DLL*
┃
┣━━━━━━━━━━━━━━━━━━━━
┃ *${prefix}POWERED BY P042*
┗━━━━━━━━━━━━━━━━━━━━`
}
exports.help = help
